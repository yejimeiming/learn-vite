// this module should not be resolved
export default 'C@1.0.0'
