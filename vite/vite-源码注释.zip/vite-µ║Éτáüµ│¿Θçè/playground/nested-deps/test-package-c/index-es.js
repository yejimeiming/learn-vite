export default 'es-C@1.0.0'
