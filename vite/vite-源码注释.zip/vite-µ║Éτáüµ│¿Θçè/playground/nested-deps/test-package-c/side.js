export { default as C } from '@vitejs/test-package-c'
