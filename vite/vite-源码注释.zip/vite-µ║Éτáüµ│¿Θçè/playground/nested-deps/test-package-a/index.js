export default 'A@2.0.0'
