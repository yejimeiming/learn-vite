export default 'D-nested@1.0.0'
