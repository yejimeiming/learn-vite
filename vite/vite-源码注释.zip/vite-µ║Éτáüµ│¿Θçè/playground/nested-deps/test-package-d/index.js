export { default as nestedD } from '@vitejs/test-package-d-nested'

export default 'D@1.0.0'
