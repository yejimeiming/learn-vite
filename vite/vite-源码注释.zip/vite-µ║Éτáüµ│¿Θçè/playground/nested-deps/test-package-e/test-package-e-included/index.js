import { testExcluded } from 'test-package-e-excluded'

export function testIncluded() {
  return testExcluded()
}
