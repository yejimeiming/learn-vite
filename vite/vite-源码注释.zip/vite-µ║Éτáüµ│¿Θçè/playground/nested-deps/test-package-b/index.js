export { default as A } from 'test-package-a'

export default 'B@1.0.0'
