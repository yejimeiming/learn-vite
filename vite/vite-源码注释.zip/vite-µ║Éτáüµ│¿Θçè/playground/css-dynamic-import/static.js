import './static.css'

export const foo = 'foo'
