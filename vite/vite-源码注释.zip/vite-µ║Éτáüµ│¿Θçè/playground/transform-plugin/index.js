// 'TRANSFORM_COUNT' is injected by the transform plugin
document.getElementById('transform-count').innerHTML = TRANSFORM_COUNT
