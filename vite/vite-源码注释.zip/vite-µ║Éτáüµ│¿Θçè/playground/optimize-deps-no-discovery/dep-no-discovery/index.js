// written in cjs, optimization should convert this to esm
module.exports = '[success]'
