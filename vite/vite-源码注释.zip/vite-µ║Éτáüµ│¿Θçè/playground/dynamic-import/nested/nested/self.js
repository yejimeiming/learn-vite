export const self = 'dynamic-import-nested-self-content'
