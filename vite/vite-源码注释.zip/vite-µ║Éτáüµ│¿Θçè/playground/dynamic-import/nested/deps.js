/* don't include dynamic import inside this file */

import '@vitejs/test-pkg'
