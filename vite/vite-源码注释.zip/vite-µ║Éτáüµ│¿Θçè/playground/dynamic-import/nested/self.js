export const self = 'dynamic-import-self-content'
