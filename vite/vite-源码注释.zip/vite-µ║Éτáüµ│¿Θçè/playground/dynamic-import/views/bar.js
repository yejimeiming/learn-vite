export const msg = 'Bar view'
