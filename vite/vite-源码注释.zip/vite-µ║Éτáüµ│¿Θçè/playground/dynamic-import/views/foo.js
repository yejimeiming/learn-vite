import { n } from '../nested/shared'
console.log('foo' + n)

export const msg = 'Foo view'
