export function hello() {
  return 'hello'
}
console.log('hello.js')
