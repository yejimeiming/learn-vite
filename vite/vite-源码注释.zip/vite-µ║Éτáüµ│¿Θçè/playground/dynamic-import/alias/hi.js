export function hi() {
  return 'hi'
}
console.log('hi.js')
