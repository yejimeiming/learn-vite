module.exports = {
  defined: __STRINGIFIED_OBJ__,
  importMetaEnvUndefined: 'import.meta.env.UNDEFINED',
  processEnvUndefined: 'process.env.UNDEFINED',
}
