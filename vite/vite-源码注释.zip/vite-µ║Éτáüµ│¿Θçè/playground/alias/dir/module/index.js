export const msg = `[success] aliased module`
