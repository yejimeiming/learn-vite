export const msg = `[success] alias to fs path`
