export const msg = `[success] alias to custom-resolver path`
