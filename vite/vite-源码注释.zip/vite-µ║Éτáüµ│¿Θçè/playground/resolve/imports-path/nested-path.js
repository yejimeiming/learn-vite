export const msg = '[success] nested path subpath imports'
