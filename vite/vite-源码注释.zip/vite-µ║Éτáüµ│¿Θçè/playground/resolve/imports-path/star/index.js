export const msg = '[success] subpath imports with star'
