export const msg = '[success] subpath imports from other package'
