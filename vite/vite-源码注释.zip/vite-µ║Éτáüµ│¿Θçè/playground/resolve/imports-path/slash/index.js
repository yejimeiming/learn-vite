export const msg = '[success] subpath imports with slash'
