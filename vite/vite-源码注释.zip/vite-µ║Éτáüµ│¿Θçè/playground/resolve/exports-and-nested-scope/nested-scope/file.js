'use strict'

// intentionally use the default export here since default import from CJS has different semantics in node
export default '[success] ES .js file within root that has type: commonjs (thanks to a package scope)'
