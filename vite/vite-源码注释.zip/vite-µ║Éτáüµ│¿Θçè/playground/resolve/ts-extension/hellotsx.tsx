export const msgTsx = '[success] use .js extension to import a tsx module'
