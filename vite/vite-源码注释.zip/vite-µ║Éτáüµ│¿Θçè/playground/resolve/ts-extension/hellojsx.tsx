export const msgJsx = '[success] use .jsx extension to import a tsx module'
