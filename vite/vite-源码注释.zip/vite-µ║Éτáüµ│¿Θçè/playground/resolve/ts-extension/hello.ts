export const msg = '[success] use .js extension to import a ts module'
