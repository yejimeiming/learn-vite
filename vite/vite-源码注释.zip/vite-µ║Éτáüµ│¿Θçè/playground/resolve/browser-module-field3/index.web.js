var browserModuleField3 = (function () {
  'use strict'

  var main = '[fail] this should not run in the browser'

  return main
})()
