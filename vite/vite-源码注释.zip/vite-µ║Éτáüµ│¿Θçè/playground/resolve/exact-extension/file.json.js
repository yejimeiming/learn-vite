export const file = '[success] file.json.js'
