export const file = '[success] file.js'
