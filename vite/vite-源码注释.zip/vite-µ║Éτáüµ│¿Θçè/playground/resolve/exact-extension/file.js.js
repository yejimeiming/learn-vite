export const file = 'file.js.js'
