const BigNumber = require('bignumber.js')

const x = new BigNumber('1111222233334444555566')

module.exports = x.toString()
