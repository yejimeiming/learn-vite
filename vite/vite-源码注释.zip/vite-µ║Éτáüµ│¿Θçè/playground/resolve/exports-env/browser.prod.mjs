export const msg = '[success] exports env (browser.prod.mjs)'
