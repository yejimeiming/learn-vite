export const msg = '[fail] mapped js file'
