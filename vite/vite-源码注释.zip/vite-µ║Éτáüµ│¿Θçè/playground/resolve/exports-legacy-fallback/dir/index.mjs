export const msg = '[success] mapped mjs file'
