module.exports = '[fail] this should not run in the browser'
