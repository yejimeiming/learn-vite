export default '[fail] this should not run in the browser'
