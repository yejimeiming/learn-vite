exports.msg = 'from cjs'
