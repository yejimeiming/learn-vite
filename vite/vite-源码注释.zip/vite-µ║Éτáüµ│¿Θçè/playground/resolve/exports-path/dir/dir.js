export const msg = '[success] mapped directory from exports'
