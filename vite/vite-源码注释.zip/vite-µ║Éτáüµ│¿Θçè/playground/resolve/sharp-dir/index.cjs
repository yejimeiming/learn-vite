module.exports = {
  last: require('es5-ext/string/#/last.js'),
}
