﻿import '@babel/runtime/helpers/esm/slicedToArray'

export const msg = '[success]'
