export const msg = 'fail exports from root (./nested/file.js)'
