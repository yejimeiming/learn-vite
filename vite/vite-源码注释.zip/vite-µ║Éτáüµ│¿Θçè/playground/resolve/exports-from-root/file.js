export const msg = '[success] exports from root (./file.js)'
