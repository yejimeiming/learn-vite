// import.mjs should take precedence
export const msg = '[success] exports with module (import.mjs)'
