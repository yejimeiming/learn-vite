// import.mjs should take precedence
export const msg = '[fail] exports with module (module.mjs)'
