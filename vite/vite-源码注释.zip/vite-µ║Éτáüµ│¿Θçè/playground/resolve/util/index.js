export function foo() {
  return '[success] resolve omitted /index.*'
}
