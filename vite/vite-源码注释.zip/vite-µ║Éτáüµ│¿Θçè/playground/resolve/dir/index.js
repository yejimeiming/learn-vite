export const file = 'dir/index.js'
