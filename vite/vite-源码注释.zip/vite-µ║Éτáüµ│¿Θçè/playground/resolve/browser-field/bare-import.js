import message from '@vitejs/test-resolve-browser-field-bare-import-fail'
export default message
