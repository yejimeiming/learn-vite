/* eslint-disable import/no-duplicates */
import ra from './no-ext'
import rb from './no-ext.js' // no substitution
import rc from './ext'
import rd from './ext.js'
import re from './ext-index/index.js'
import rf from './ext-index'
import rg from './no-ext-index/index.js' // no substitution

export { ra, rb, rc, rd, re, rf, rg }
