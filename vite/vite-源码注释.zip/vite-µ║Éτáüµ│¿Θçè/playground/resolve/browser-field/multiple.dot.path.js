const fs = require('node:fs')
console.log('this should not run in the browser')
