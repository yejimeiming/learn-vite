import jsdom from 'jsdom' // should be redirected to empty module
export default ''
