console.log('vite cli works!')
