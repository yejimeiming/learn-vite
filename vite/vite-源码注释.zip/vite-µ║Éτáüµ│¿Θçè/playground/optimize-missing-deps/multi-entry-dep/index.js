const path = require('node:path')

exports.name = path.normalize('./Server')
