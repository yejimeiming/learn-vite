import { name } from '@vitejs/test-multi-entry-dep'

export function sayName() {
  return name
}
