import { sayName } from '@vitejs/test-missing-dep'

export const name = sayName()
