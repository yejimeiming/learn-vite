export const virtual = '[success]'
