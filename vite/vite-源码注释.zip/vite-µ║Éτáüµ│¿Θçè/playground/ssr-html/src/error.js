export function error() {
  throw new Error('e')
}
