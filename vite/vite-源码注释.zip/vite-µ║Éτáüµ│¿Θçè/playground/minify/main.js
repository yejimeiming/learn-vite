import './test.css'

if (window) {
  console.log('hello world')
}
