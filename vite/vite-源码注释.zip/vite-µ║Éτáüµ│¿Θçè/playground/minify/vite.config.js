import { defineConfig } from 'vite'

export default defineConfig({
  esbuild: {
    minifySyntax: false,
  },
})
