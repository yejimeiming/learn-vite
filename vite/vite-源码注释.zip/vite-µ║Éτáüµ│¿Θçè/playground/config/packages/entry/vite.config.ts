import moduleCondition from '@vite/test-config-plugin-module-condition'
import { array } from '../siblings/foo'

export default {
  array,
  moduleCondition,
}
