console.log('message from sideEffects script')
