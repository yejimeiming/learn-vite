import './dep3'
import { log } from './common'

log('shared')
