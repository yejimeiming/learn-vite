import './dep2'
import { log } from './common'

log('dep3')
