import { log } from './common'

log('dep2')
