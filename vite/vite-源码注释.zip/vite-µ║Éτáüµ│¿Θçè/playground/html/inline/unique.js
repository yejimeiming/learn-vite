import { log } from './common'
import './dep2'

log('unique')
