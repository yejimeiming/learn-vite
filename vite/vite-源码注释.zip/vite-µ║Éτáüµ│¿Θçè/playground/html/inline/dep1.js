import { log } from './common'

log('dep1')
