export const foo = 1
