import { a } from './named'
import def from './default'

console.log(`>>>>>> ${a} ${def}`)
