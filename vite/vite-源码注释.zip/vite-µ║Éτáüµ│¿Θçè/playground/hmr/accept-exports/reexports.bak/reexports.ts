import { a } from './accept-named'

console.log('accept-named:' + a)

console.log('>>> ready')
