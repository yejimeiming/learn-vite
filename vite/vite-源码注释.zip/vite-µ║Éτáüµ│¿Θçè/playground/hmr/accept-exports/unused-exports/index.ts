import './unused'
import { foo } from './used'

console.log('used:' + foo)
