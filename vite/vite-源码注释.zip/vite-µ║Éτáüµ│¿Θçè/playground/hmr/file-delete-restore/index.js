import { render } from './runtime'
import { childValue, parentValue } from './parent'

render({ parent: parentValue, child: childValue })
