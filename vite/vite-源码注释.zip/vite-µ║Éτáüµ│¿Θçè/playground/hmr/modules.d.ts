declare module 'virtual:file' {
  export const virtual: string
}
