import './sub.css'

export default 'sub2-name'
