import './sub.css'

export default 'sub1-name'
