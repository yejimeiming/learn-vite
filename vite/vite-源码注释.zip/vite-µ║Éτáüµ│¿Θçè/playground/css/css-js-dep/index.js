import './foo.css'
import barModuleClasses from './bar.module.css'

export { barModuleClasses }
