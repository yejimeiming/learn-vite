const message = 'from jsfile.css.js'
export default message
