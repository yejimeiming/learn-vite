import config from '../../vite.config-no-css-minify'
export default config
