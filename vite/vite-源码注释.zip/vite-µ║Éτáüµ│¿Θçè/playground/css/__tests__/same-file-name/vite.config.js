import config from '../../vite.config-same-file-name'
export default config
