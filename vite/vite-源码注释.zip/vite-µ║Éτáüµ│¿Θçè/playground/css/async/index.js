import('./async-1.js')
import('./async-2.js')
import('./async-3.js')
