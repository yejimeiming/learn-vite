import { createButton } from './base'
import styles from './async-3.module.css'

createButton(`${styles['async-pink']} modules-pink`)
