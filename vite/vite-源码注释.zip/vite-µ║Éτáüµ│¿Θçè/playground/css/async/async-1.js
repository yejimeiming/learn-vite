import { createButton } from './base'
import './async-1.css'

createButton('async-blue')
