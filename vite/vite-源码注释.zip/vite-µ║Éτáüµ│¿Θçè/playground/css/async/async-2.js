import { createButton } from './base'
import './async-2.css'

createButton('async-green')
